package com.krishna.dao;

import java.util.List;

import com.krishna.model.Question;

public interface QuestionDao {
	public void addQuestion(Question q);
	public List<Question> getQuestion(int id);
}
