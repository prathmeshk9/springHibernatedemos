package com.krishna.controller;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.krishna.model.Question;
import com.krishna.service.QuestionService;

@Controller
public class QuestionController {
	
	final static Logger logger = Logger.getLogger(QuestionController.class);
	
	@Autowired
	private QuestionService questionService;

	@RequestMapping("/hello")
	public String hello(){
	
		return "hello";
	}
	
	@RequestMapping("/do.action")
	public String doActions(@RequestParam("que") String que,
			@RequestParam("option") String ans){
		

		
		logger.info("This is info : " + "MyApp");
		
		Question q  =new Question(1, que, ans);
		
		questionService.addQuestion(q);
		
		return "exam";
	}
}
