package com.krishna.service;

import java.util.List;

import com.krishna.model.Question;

public interface QuestionService {
	public void addQuestion(Question q);
	public List<Question> getQuestion(int id);
}
