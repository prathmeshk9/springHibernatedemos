package com.krishna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.krishna.dao.QuestionDao;
import com.krishna.model.Question;

@Service
public class QuestionServiceImpl implements QuestionService{
	
	@Autowired
	private QuestionDao questionDao;
	
	@Override
	public void addQuestion(Question q) {
		questionDao.addQuestion(q);
		
	}

	@Override
	public List<Question> getQuestion(int id) {
		
		return questionDao.getQuestion(id);
	}

}
