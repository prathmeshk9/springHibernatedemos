package com.krishna.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.krishna.model.Question;

@Repository
public class QuestionDaoImpl implements QuestionDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Transactional
	public void addQuestion(Question q) {
		sessionFactory.getCurrentSession().save(q);		
	}

	@Transactional
	public List<Question> getQuestion(int id) {
		
		@SuppressWarnings("unchecked")
		List<Question> qlist = sessionFactory.getCurrentSession().createQuery("from test_tbl").list();
		
		return qlist;
	}

}
